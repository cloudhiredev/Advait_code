
export const PrimaryButton = ({text, onClick}) => {
  const handleClick = (event) => {
    event.preventDefault();
    onClick();
  };
  return (
    <>
    <button onClick={(e)=>handleClick(e)} className='primary'>{text}</button>
    </>
  )
}
