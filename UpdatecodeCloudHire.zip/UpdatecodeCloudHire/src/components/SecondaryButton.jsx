
export const SecondaryButton = ({text, onClick}) => {
    const handleClick = (event) => {
      event.preventDefault();
      onClick();
    };
    return (
      <>
      <button onClick={(e)=>handleClick(e)} className='secondary-btn'>{text}</button>
      </>
    )
  }
  