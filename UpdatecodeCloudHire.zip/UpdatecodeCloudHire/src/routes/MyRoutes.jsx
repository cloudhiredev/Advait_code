import { createBrowserRouter } from "react-router-dom";
// import { Home } from "../pages/Home";
import { Login } from "../pages/Login";
import { VerifyDetails } from "../pages/VerifyDetails";

const MyRoutes = createBrowserRouter([
  {
    path: "/",
    element: <Login />,
    children: [
      {
        path: "dashboard",
        element: <h1 className="text-3xl font-bold underline bg-slate-600">Dashboard</h1>,
      },
    ],
  },
  {
    path: "/login",
    element: <Login />,
  },
  {
    path: "/verifydetails",
    element: <VerifyDetails />,
  },
]);
export default MyRoutes;
