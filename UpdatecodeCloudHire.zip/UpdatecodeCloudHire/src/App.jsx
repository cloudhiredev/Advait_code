import { RouterProvider } from 'react-router-dom'
import './App.css'
import MyRoutes from './routes/MyRoutes'

function App() {

  return (
 <RouterProvider router={MyRoutes} />
  )
}

export default App
