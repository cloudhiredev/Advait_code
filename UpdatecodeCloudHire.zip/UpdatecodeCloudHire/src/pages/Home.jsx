import { Outlet } from "react-router-dom";

export const Home = () => {
  return (
    <>
      <header>Header</header>
      <Outlet/>
      <footer>Footer</footer>
    </>
  );
};
