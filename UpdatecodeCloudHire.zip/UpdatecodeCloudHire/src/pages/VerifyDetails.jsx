import bg1 from "../assets/bg-oval.png";
import bg2 from "../assets/bg-1.png";
import Dropdown from "../components/Dropdown";
import { useState } from "react";
import "react-date-picker/dist/DatePicker.css";
import "react-calendar/dist/Calendar.css";
import DatePicker from "react-date-picker";
import { PrimaryButton } from "../components/PrimaryButton";
import { SecondaryButton } from "../components/SecondaryButton";
export const VerifyDetails = () => {
  const [selectedOption, setSelectedOption] = useState(null);
  const [date, SetDate] = useState(new Date());
  const [step, setStep] = useState(1);

  const options = [
    { label: "Full Time", value: "option1" },
    { label: "Part Time", value: "option2" },
    { label: "Self Employed", value: "option3" },
  ];

  const handleSelect = (option) => {
    setSelectedOption(option);
  };

  const handleNext = () => {
    if (step <= 4) setStep(step + 1);
    window.scrollTo(0, 0);
  };
  const handlePrevious = () => {
    if (step > 1) setStep(step - 1);
  };

  return (
    <>
      <img className="absolute" src={bg1} />
      <img className="absolute" src={bg2} />
      <form
        className="verify-details-form p-4 w-3/4 bg-white m-auto relative"
        action=""
      >
        <span className="step-text">Step {step}/4</span>
        {step == 1 ? (
          <>
            <h5>Verify your details</h5>
            <hr className="my-2" />
            <div className="flex flex-wrap w-full">
              {/* row 1 */}
              <div className="flex flex-wrap justify-between my-2 w-full gap-2">
                <div className="custom-col">
                  <label>Full Name</label>
                  <input
                    className="form-input"
                    type="text"
                    placeholder="Enter Your Name"
                  />
                </div>
                <div className="custom-col">
                  <label>Email ID</label>
                  <input
                    className="form-input"
                    type="text"
                    placeholder="Enter Your Email Id"
                  />
                </div>
                {/* row 2 */}
                <div className="flex w-full flex-wrap justify-between my-2 gap-2">
                  <div className="custom-col">
                    <label>Mobile Number</label>
                    <input
                      className="form-input"
                      type="text"
                      placeholder="Enter Your Mobile number"
                    />
                  </div>
                  <div className="custom-col">
                    <label>Location</label>
                    <input
                      className="form-input"
                      type="text"
                      placeholder="Select your location"
                    />
                  </div>
                </div>
                {/* row 3 */}
                <div className="flex w-full flex-wrap justify-between my-2 gap-2">
                  <div className="custom-col">
                    <label>Current Role</label>
                    <input
                      className="form-input"
                      type="text"
                      placeholder="Frontend Developer"
                    />
                  </div>
                  <div className="custom-col">
                    <label>Current Work Experience</label>
                    <input
                      className="form-input"
                      type="text"
                      placeholder="1 year 4 months"
                    />
                  </div>
                </div>

                {/* row 4 */}
                <div className="flex w-full flex-wrap justify-between my-2 gap-2">
                  <div className="custom-col">
                    <label>Expert Skills (Your Top 3 Skills)</label>
                    <input
                      className="form-input"
                      type="text"
                      placeholder="Enter your Top 3 Skills"
                    />
                  </div>
                  <div className="custom-col">
                    <label>Technical Skills (Your Top 3 Skills)</label>
                    <input
                      className="form-input"
                      type="text"
                      placeholder="Enter your Top 3 Skills"
                    />
                  </div>
                </div>
                <div className="flex w-full flex-wrap justify-between gap-2">
                  <div className="custom-col flex flex-wrap gap-4">
                    <span className="skill-pill">UX Research</span>
                    <span className="skill-pill">UX Design</span>
                    <span className="skill-pill">Visual Design</span>
                  </div>
                  <div className="custom-col flex flex-wrap gap-4">
                    <span className="skill-pill">UX Research</span>
                    <span className="skill-pill">UX Design</span>
                    <span className="skill-pill">Visual Design</span>
                  </div>
                </div>
                <h5>Work Experience</h5>
                {/* row 6 */}
                <div className="flex w-full flex-wrap justify-between my-2 gap-2">
                  <div className="custom-col">
                    <label>Company Name</label>
                    <input
                      className="form-input"
                      type="text"
                      placeholder="Enter your company name"
                    />
                  </div>
                  <div className="custom-col">
                    <label>Employment Type</label>
                    <Dropdown options={options} onSelect={handleSelect} />
                  </div>
                </div>
                {/* row */}
                <div className="flex w-full flex-wrap justify-between my-2 gap-2">
                  <div className="custom-col">
                    <label>Role</label>
                    <input
                      className="form-input"
                      type="text"
                      placeholder="Frontend Developer"
                    />
                  </div>
                  <div className="custom-col">
                    <label>Location</label>
                    <input
                      className="form-input"
                      type="text"
                      placeholder="Bengaluru"
                    />
                  </div>
                </div>
                {/* row */}
                <div className="flex w-full flex-wrap justify-between my-2 gap-2">
                  <div className="custom-col">
                    <label>Start Date</label>
                    <DatePicker
                      className="form-input"
                      onChange={SetDate}
                      value={date}
                    />
                  </div>
                  <div className="custom-col">
                    <label>End Date</label>
                    <DatePicker
                      className="form-input"
                      onChange={SetDate}
                      value={date}
                    />
                  </div>
                </div>
                <div className="custom-col flex items-center">
                  <input type="checkbox" />
                  <label className="ml-2">I am working on this role</label>
                </div>
                {/*  */}
                <div className="flex w-full flex-wrap justify-between my-2 gap-2">
                  <label>Description</label>
                  <textarea
                    className="w-full border rounded focus:outline-blue-700 p-2"
                    id="w3review"
                    name="w3review"
                    rows="4"
                    cols="50"
                  >
                    In my previous role, I proactively conducted research to
                    identify user pain points and successfully solved existing
                    problems. Specializing in the mobile application, I
                    implemented gamification elements, resulting in a remarkable
                    48% increase in user engagement. Simultaneously, I
                    spearheaded a comprehensive redesign of the website and
                    internal dashboard, introducing innovative solutions to
                    enhance the overall user experience. Additionally, I curated
                    engaging LinkedIn posts to elevate brand presence and
                    further boost user engagement across platforms.
                  </textarea>
                  <div className="custom-col">
                    <label>Company Website Link</label>
                    <input
                      className="form-input"
                      type="text"
                      placeholder="elevatozloyalty.com"
                    />
                  </div>
                </div>
                {/*  */}
                <h5>Education</h5>
                {/*  */}
                <div className="flex w-full flex-wrap justify-between my-2 gap-2">
                  <div className="custom-col">
                    <label>College Name</label>
                    <input
                      className="form-input"
                      type="text"
                      placeholder="Enter your college name"
                    />
                  </div>
                  <div className="custom-col">
                    <label>Employment Type</label>
                    <Dropdown options={options} onSelect={handleSelect} />
                  </div>
                </div>
                {/*  */}
                <div className="flex w-full flex-wrap justify-between my-2 gap-2">
                  <div className="custom-col">
                    <label>Field Of Study</label>
                    <input
                      className="form-input"
                      type="text"
                      placeholder="Computer Science"
                    />
                  </div>
                  <div className="custom-col">
                    <label>Location</label>
                    <input
                      className="form-input"
                      type="text"
                      placeholder="Select your location"
                    />
                  </div>
                  <div className="flex w-full flex-wrap justify-between my-2 gap-2">
                    <label>Description</label>
                    <textarea
                      className="w-full border rounded focus:outline-blue-700 p-2"
                      id="w3review"
                      name="w3review"
                      rows="4"
                      cols="50"
                    >
                      Currently, I specialize in merging research and design to
                      create intuitive digital experiences. My focus revolves
                      around understanding user behaviors, crafting visually
                      appealing interfaces, and contributing innovative
                      solutions for diverse platforms.
                    </textarea>
                  </div>
                </div>
                {/*  */}
                <div className="flex w-full flex-wrap justify-between my-2 gap-2">
                  <div className="custom-col">
                    <label>Start Date</label>
                    <DatePicker
                      className="form-input"
                      onChange={SetDate}
                      value={date}
                    />
                  </div>
                  <div className="custom-col">
                    <label>End Date</label>
                    <DatePicker
                      className="form-input"
                      onChange={SetDate}
                      value={date}
                    />
                  </div>
                </div>
                <div className="custom-col flex items-center">
                  <input type="checkbox" />
                  <label className="ml-2">I am studying here</label>
                </div>
              </div>
            </div>
          </>
        ) : step == 2 ? (
          <>
            {/*  */}
            <div className="flex w-full flex-wrap justify-between my-2 gap-2">
              <label>About</label>
              <textarea
                className="w-full border rounded focus:outline-blue-700 p-2"
                id="w3review"
                name="w3review"
                rows="4"
                cols="50"
              >
                Creative and detail-oriented UI/UX Designer with a solid
                one-year track record in crafting engaging and intuitive digital
                experiences. Proficient in designing a diverse range of
                products, including mobile apps, websites, and SaaS solutions.
                My passion lies in merging user-centric design principles with
                innovative solutions to address digital challenges effectively.
              </textarea>
            </div>
            {/*  */}
            <div className="flex w-full flex-wrap justify-between my-2 gap-2">
              <div className="custom-col">
                <label>Current Salary</label>
                <p className="my-1 text-sm text-blue-700">
                  *Stand out from the crowd by updating your current salary
                  information
                </p>
                <input
                  className="form-input"
                  type="text"
                  placeholder="4 lakh"
                />
              </div>
              <div className="custom-col">
                <label>Expected Salary</label>
                <p className="my-1 text-sm text-blue-700">
                  *Stand out from the crowd by updating your current salary
                  information
                </p>
                <input
                  className="form-input"
                  type="text"
                  placeholder="6 lakh"
                />
              </div>
            </div>
            {/*  */}
            <div className="flex w-full flex-wrap justify-between my-2 gap-2">
              <div className="custom-col">
                <label>Notice Period</label>
                <input
                  className="form-input"
                  type="text"
                  placeholder="2 months"
                />
              </div>
              <div className="custom-col">
                <label>Portfolio Links</label>
                <input
                  className="form-input"
                  type="text"
                  placeholder="google.com"
                />
              </div>
            </div>
            {/*  */}
            <div className="flex w-full flex-wrap justify-between my-2 gap-2">
              <div className="custom-col">
                <label>Languages</label>
                <input
                  className="form-input"
                  type="text"
                  placeholder="Enter languages you know"
                />
              </div>
              <div className="custom-col">
                <label>Select Time Slots (Time zone you prefer to work)</label>
                <input
                  className="form-input"
                  type="text"
                  placeholder="Select any slot which your more productive to work"
                />
              </div>
            </div>
            <div className="flex w-full flex-wrap justify-between my-2 gap-2">
              <div className="custom-col flex flex-wrap gap-4">
                <span className="skill-pill">English</span>
                <span className="skill-pill">Hindi</span>
                <span className="skill-pill">Telugu</span>
              </div>
              <div className="custom-col flex flex-wrap gap-4">
                <span className="skill-pill">6pm to 3am</span>
                <span className="skill-pill">10pm to 12am</span>
                <span className="skill-pill">12pm to 3pm</span>
              </div>
              <div className="custom-col flex flex-wrap gap-4">
                <label>Availability</label>
                <Dropdown options={options} onSelect={handleSelect} />
              </div>
              <div className="w-full flex items-center mb-5">
                <input type="checkbox" />
                <label className="ml-2">
                  I hereby confirm that all the information provided is accurate
                  and truthful, attesting to the validity of the details shared.
                </label>
              </div>
            </div>
            {/*  */}
          </>
        ) : step == 3 ? (
          
          <>
          {/* */}
          <div className="flex w-full flex-wrap justify-between my-2 gap-2">
              <label>Record 1 Minute Video </label>
              <hr/>             
              <a href="#"> Skip </a>
            </div>
          {/* */}
         <div className="row video-recording">
            <h3>
                 Video Record Instructions
              </h3>
              <ol>
                <li>Prepare for Recording:
                  <ul>
                    <li>Find a quiet, well-lit location with a stable internet connection for recording your video interview.</li>
                    <li>Ensure you have your responses prepared and are ready to speak confidently and clearly.</li>
                  </ul>
                </li>
                <li>Start Recording:
                  <ul>
                    <li>Once you click the "Record Video" button below, a question will be presented to you.</li>
                    <li>You will have 15 seconds to prepare your answer before the recording starts automatically.</li>
                  </ul>
                </li>
                <li>Keep it Concise:
                  <ul>
                    <li>You'll have 1 minute to answer each question., so make sure to provide clear and concise responses based on the information provided.</li>
                    <li>The recording will automatically stop after 1 minute.</li>
                  </ul>
                </li>
              </ol>

         </div>


          {/* */}
          </>
          
        ) : (
          <>
          {/* */}
          <div className="flex w-full flex-wrap justify-between my-2 gap-2">
              <label>Record 1 Minute Video </label>
              <hr/>             
              <a href="#"> Skip </a>
            </div>
          {/* */}
         <div className="row video-recording">
            <h3>
                Questions
              </h3>
              <ol>
                <li>Behavioral Question:
                  <ul>
                    <li>Describe your approach to collaborating with team members on projects or tasks.</li>                    
                  </ul>
                </li>                
              </ol>
              <div className="flex h-4/5 w-4/5 justify-center items-center gap-8 m-auto">
              <video className="rounded-md h-4/5 w-4/5" controls>
                <source src="https://docs.material-tailwind.com/demo.mp4" type="video/mp4" />
                Your browser does not support the video tag.
              </video>
              </div>
            </div>
          {/* */}
          </>
        )}
        {/*  */}
        <div className="flex w-full flex-wrap justify-end my-2 gap-2">
          <div className="custom-col custom-col2 flex">
            <div>
              <SecondaryButton onClick={() => handlePrevious()} text="Back" />
            </div>
            <div className="ml-4">
              <PrimaryButton onClick={() => handleNext()} text={"Next"} />
            </div>
          </div>
        </div>
        {/*  */}
      </form>
    </>
  );
};
