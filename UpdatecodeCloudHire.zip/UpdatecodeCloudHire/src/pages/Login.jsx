import { PrimaryButton } from "../components/PrimaryButton";
import loginLeft from "../assets/login-left.png";
import { useEffect, useState } from "react";
import OtpInput from "react-otp-input";
import { useNavigate } from "react-router-dom";


export const Login = () => {
  const [submitted, setSubmitted] = useState(false);
  const [otp, setOtp] = useState("");

  const navigate = useNavigate();
  const handleSubmit = (e) => {
    console.log("clicked", e);
    setSubmitted(true);
  };

  const otpcss = {
    width: "56px",
    height: "52px",
    background: "#FFFFFF",
    border: "1px solid #A0A3BD",
  };

  useEffect(() => {
    console.log(otp);
  }, [otp]);

  return (
    <>
      <div className="h-screen flex w-screen justify-between items-center">
        <div className="flex h-4/5 w-4/5 justify-center items-center gap-8 m-auto">
          <img src={loginLeft} className="img" />
          <div className="flex justify-center">
            <form className="w-9/12 flex flex-col justify-between gap-8  ">
              <h1>Welcome to CloudHire!</h1>
              <span>
                Your profile is set; just verify details to unlock exciting
                career opportunities and take a significant step closer to your
                dream job.
              </span>
              <div className="flex flex-col gap-2 otp-parent">
                {submitted ? (
                  <>
                    <label>Enter the OTP sent your Email Id</label>
                    <OtpInput
                      inputClassName="otp-input"
                      inputStyle={{ ...otpcss, borderRadius: "8px" }}
                      value={otp}
                      onChange={setOtp}
                      numInputs={5}
                      renderInput={(props) => <input {...props} />}
                    />
                  </>
                ) : (
                  <>
                    <label>Enter Your Email Id</label>
                    <input
                      className="form-input"
                      type="text"
                      placeholder="Enter Your Email Id"
                    />
                  </>
                )}
              </div>
              {submitted ? (
                <PrimaryButton onClick={()=>navigate('/verifydetails')} text={"Verify OTP"} />
              ) : (
                <PrimaryButton onClick={handleSubmit} text={"SendOTP"} />
              )}
              <span>
                By continuing , you agree to CloudHire’s Terms of Use and
                confirm that you have read CloudHire’s Privacy Policy
              </span>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};
